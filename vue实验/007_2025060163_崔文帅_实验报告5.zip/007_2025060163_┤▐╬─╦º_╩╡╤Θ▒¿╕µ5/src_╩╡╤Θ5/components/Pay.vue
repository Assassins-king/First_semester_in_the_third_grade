<template>
  <div>pay</div>
</template>

<script>
export default {
  name: "Pay"
}
</script>

<style scoped>

</style>