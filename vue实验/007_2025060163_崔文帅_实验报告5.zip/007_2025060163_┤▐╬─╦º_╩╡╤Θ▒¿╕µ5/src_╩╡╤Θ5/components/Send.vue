<template>
  <div>send</div>
</template>

<script>
export default {
  name: "Send"
}
</script>

<style scoped>

</style>