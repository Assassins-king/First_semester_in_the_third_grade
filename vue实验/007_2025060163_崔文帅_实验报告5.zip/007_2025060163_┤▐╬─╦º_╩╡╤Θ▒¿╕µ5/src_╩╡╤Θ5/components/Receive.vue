<template>
  <div>receive</div>
</template>

<script>
export default {
  name: "Receive"
}
</script>

<style scoped>

</style>